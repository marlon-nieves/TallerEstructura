/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import java.util.LinkedList;

/**
 *
 * @author Marlon
 */
public class Componente {
    private LinkedList<Pieza> piezas;
    private double precio;
    
    public Componente(){
       this.piezas = new LinkedList<>();
       this.precio = 0;
    }
    
    public Pieza addPieza(Pieza pieza){
        this.piezas.add(pieza);
        return pieza;
    }
    
    public double calcularValor(){
        for (int i = 0; i < this.piezas.size(); i++) {
            this.precio+= this.piezas.get(i).calcularPrecio();
        }
        return this.precio;
    }
    
    public int getCantidadPiezas(){
        return this.piezas.size();
    }
    
}
