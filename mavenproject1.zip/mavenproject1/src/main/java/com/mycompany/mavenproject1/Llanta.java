/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import java.util.LinkedList;
/**
 *
 * @author Marlon
 */
public class Llanta extends Pieza {

    private LinkedList<Tornillo> tornillos;
    private int precio;

    public Llanta() {
        this.tornillos = new LinkedList<>();
        this.precio = 50000;
    }
    
    public void addPieza(){
        
    }

    @Override
    public double calcularPrecio() {
        for (int i = 0; i < this.tornillos.size(); i++) {
            this.precio += this.tornillos.get(i).calcularPrecio();
        }
        return this.precio;
    }

}
