/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import java.util.LinkedList;

/**
 *
 * @author Marlon
 */
public abstract class Pieza {
    private int precio;
    private String nombre;
    private LinkedList<Pieza> piezas;
    private String codigo;
          
    public abstract double calcularPrecio();
}
