/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import java.util.LinkedList;

/**
 *
 * @author Marlon
 */
public class Tornillo extends Pieza{
    private double precio;
  
    public Tornillo setPrice(double price){
        this.precio = price;
        return this;
    }
    
    @Override //sobreescribiendo un metodo
    public double calcularPrecio() {
        return this.precio;
    }
    
}
